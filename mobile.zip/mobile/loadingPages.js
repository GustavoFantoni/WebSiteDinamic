    const pages = {
        1: { src: "pages/home-shop.html", distanceBall: 6, classBlack: "fi a fi-rs-shopping-bag", classWhite: "fi fi-rs-shopping-bag" },
        2: { src: "pages/cart.html", distanceBall: 28.5, classBlack: "fi a fi-rs-shopping-cart", classWhite: "fi fi-rs-shopping-cart"  },
        3: { src: "pages/contact.html", distanceBall: 51, classBlack: "fi a fi-rs-headset", classWhite: "fi fi-rs-headset"  },
        4: { src: "pages/account.html", distanceBall: 74, classBlack: "fi a fi-rs-user", classWhite: "fi fi-rs-user"  }
    };

    const contentPage = document.getElementById("content-page")
    const ballNavbar = document.querySelector("div.ball-navbar")

    document.querySelectorAll("#item-01, #item-02, #item-03, #item-04").forEach((item, index) => {
        item.addEventListener('click', () => acao(index + 1)); 
    });
    acao(1)
    function acao(page) {
        const pageSrc = pages[page]; 
        contentPage.innerHTML = '';



        fetch(pageSrc.src)
        .then(response => response.text())
        .then(data => {
            contentPage.innerHTML = data;
        })
        .catch(error => {
            console.error('Erro ao carregar o conteúdo:', error);
        });

        ballNavbar.style.left = pageSrc.distanceBall + "%";

        document.querySelectorAll("#item-01, #item-02, #item-03, #item-04").forEach((item, index) => {
            const icon = item.querySelector("i.fi");
            if (index + 1 === page) {
                icon.className = pageSrc.classBlack;
            } else {
                const pageOther = pages[index + 1];
                icon.className = pageOther.classWhite; 
            }
        });

    }


