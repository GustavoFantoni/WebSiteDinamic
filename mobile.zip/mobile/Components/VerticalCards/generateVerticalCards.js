const cardData = [
    { descriptionCard: "Card 1", nameProduct: "Nome produto", valueProduct: "R$ 100,00", imageProduct: "../../images/imageTest.png" },
    { descriptionCard: "Card 2", nameProduct: "Nome produto", valueProduct: "R$ 100,00", imageProduct: "../../images/imageTest.png" },
    { descriptionCard: "Card 3", nameProduct: "Nome produto", valueProduct: "R$ 100,00", imageProduct: "../../images/imageTest.png" },
    { descriptionCard: "Card 4", nameProduct: "Nome produto", valueProduct: "R$ 100,00", imageProduct: "../../images/imageTest.png" }
  ];



  const cardContainer = document.getElementById("vertical-card-container");
  function createCards(data) {
      data.forEach((product) => {
  
          const card = document.createElement("section");
          card.classList.add("vertical-card-product");
  
          card.innerHTML = `
              <div class="vertical-card">
                    <div class="top-vertical-card">
                        <img src="${product.imageProduct}" alt="${product.nameProduct}" class="image-vertical-product">
                    </div>
                    <div class="top-vertical-card">
                        <p class="description-vertical-card">${product.descriptionCard}</p>
                        <h2 class="name-vertical-product">${product.nameProduct}</h2>
                        <p class="value-vertical-product">${product.valueProduct}</p>
                        <button class="add-card"><i class="fi a fi-rs-shopping-cart"></i></button>
                    </div>
              </div>
          `;
  
          cardContainer.appendChild(card);
      });
  }
  
  createCards(cardData);