const cardData = [
    { descriptionCard: "Card 1", nameProduct: "Nome produto", valueProduct: "R$ 100,00", imageProduct: "../../images/imageTest.png" },
    { descriptionCard: "Card 2", nameProduct: "Nome produto", valueProduct: "R$ 100,00", imageProduct: "../../images/imageTest.png" },
    { descriptionCard: "Card 3", nameProduct: "Nome produto", valueProduct: "R$ 100,00", imageProduct: "../../images/imageTest.png" },
    { descriptionCard: "Card 4", nameProduct: "Nome produto", valueProduct: "R$ 100,00", imageProduct: "../../images/imageTest.png" }
  ];
 

const cardContainer = document.getElementById("card-container");
function createCards(data) {
    data.forEach((product) => {

        const card = document.createElement("section");
        card.classList.add("card-product");

        card.innerHTML = `
            <div class="left-card">
                <img src="${product.imageProduct}" alt="${product.nameProduct}" class="image-product">
            </div>
            <div class="right-card">
                <p class="description-card">${product.descriptionCard}</p>
                <h2 class="name-product">${product.nameProduct}</h2>
                <p class="value-product">${product.valueProduct}</p>
                <button class="add-card"><i class="fi a fi-rs-shopping-cart"></i></button>
            </div>
        `;

        cardContainer.appendChild(card);
    });
}

createCards(cardData);